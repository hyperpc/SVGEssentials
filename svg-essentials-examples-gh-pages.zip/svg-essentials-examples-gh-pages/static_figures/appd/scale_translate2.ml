<math>
<mrow>
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> 0 </mtd>
<mtd> tx </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
<mtd> ty </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo>&#8226;</mo>

<mtable>
<mtr>
<mtd> sx </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> sy </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo>=</mo>

<mtable>
<mtr>
<mtd> sx </mtd>
<mtd> 0 </mtd>
<mtd> tx </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> sy </mtd>
<mtd> ty </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

</mrow>
</math>
