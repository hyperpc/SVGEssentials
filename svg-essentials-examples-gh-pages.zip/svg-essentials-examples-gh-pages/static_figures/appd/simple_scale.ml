<math>
<mrow>
<mtable>
<mtr>
<mtd> 3 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 1.5 </mtd>
</mtr>
</mtable>
<mo>&#8226;</mo>
<mtable>
<mtr>
<mtd> x </mtd>
</mtr>
<mtr>
<mtd> y </mtd>
</mtr>
</mtable>

<mo>=</mo>
<mtable>
<mtr>
<mtd> 3&#xb7;x + 0&#xb7;y </mtd>
</mtr>
<mtr>
<mtd>  0&#xb7;x + 1.5&#xb7;y  </mtd>
</mtr>
</mtable>
<mo>=</mo>
<mtable>
<mtr>
<mtd> 3x </mtd>
</mtr>
<mtr>
<mtd> 1.5y </mtd>
</mtr>
</mtable>

</mrow>
</math>
