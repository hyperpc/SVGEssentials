<math>
<mrow>
<!-- rotate -->
<mtable>
<mtr>
<mtd> a </mtd>
<mtd> c </mtd>
<mtd> e </mtd>
</mtr>
<mtr>
<mtd> b </mtd>
<mtd> d </mtd>
<mtd> f </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

</mrow>
</math>
