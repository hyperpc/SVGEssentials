<math>
<mrow>
<mtable>
<mtr>
<mtd> x </mtd>
</mtr>
<mtr>
<mtd> y </mtd>
</mtr>
</mtable>
<mo>+</mo>
<mtable>
<mtr>
<mtd> 7 </mtd>
</mtr>
<mtr>
<mtd> 2 </mtd>
</mtr>
</mtable>

<mo>=</mo>

<mtable>
<mtr>
<mtd> x+7 </mtd>
</mtr>
<mtr>
<mtd> y+2 </mtd>
</mtr>
</mtable>
</mrow>
</math>
