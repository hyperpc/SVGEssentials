<math>
<mrow>
<mtable>
<mtr>
<mtd> 22.3 </mtd>
<mtd> 26 </mtd>
<mtd> 27.2 </mtd>
<mtd> 24.8 </mtd>
<mtd> 28 </mtd>
<mtd> 25 </mtd>
<mtd> 28.2 </mtd>
</mtr>
<mtr>
<mtd> 30.3 </mtd>
<mtd> 30.4 </mtd>
<mtd> 28 </mtd>
<mtd> 26.4 </mtd>
<mtd> 29.9 </mtd>
<mtd> 27.2 </mtd>
<mtd> 26 </mtd>
</mtr>
</mtable>
</mrow>
</math>
