<math>
<mrow>
<mtable>
<mtr>
<mtd> 3 </mtd>
</mtr>
<mtr>
<mtd> 5 </mtd>
</mtr>
<mtr>
<mtd> 1 </mtd>
</mtr>
</mtable>
</mrow>
</math>
