<math>
<mrow>
<mtable>
<mtr>
<mtd> a<msub>0</msub> </mtd>
<mtd> a<msub>1</msub> </mtd>
<mtd> a<msub>2</msub> </mtd>
<mtd> a<msub>3</msub> </mtd>
<mtd> a<msub>4</msub> </mtd>
</mtr>

<mtr>
<mtd> a<msub>5</msub> </mtd>
<mtd> a<msub>6</msub> </mtd>
<mtd> a<msub>7</msub> </mtd>
<mtd> a<msub>8</msub> </mtd>
<mtd> a<msub>9</msub> </mtd>
</mtr>
<mtr>
<mtd> a<msub>10</msub> </mtd>
<mtd> a<msub>11</msub> </mtd>
<mtd> a<msub>12</msub> </mtd>
<mtd> a<msub>13</msub> </mtd>
<mtd> a<msub>14</msub> </mtd>
</mtr>

<mtr>
<mtd> a<msub>15</msub> </mtd>
<mtd> a<msub>16</msub> </mtd>
<mtd> a<msub>17</msub> </mtd>
<mtd> a<msub>18</msub> </mtd>
<mtd> a<msub>19</msub> </mtd>
</mtr>

<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

</mrow>
</math>
