<math>
<mrow>
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> 0 </mtd>
<mtd> tx </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
<mtd> ty </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo>&#8226;</mo>

<mtable>
<mtr>
<mtd> sx </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> sy </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo>&#8226;</mo>

<mtable>
<mtr>
<mtd> 3 </mtd>
</mtr>
<mtr>
<mtd> 5 </mtd>
</mtr>
<mtr>
<mtd> 1 </mtd>
</mtr>
</mtable>

</mrow>
</math>
