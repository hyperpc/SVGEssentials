java -cp xercesImpl.jar:.  MLtoSVG ${1}.ml > ${1}.svg

