<math>
<mrow>
<!-- rotate -->
<mtable>
<mtr>
<mtd> cos(a) </mtd>
<mtd> -sin(a) </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> sin(a) </mtd>
<mtd> cos(a) </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo> </mo>

<!-- skew x -->
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> tan(ax) </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo> </mo>

<!-- skew y -->
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> tan(ay) </mtd>
<mtd> 1 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>


</mrow>
</math>
