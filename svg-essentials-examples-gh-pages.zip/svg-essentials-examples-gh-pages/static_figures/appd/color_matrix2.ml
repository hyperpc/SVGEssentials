<math>
<mrow>
<mtable>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
</mtr>

<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0.9 </mtd>
<mtd> 0 </mtd>
</mtr>
<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0.9 </mtd>
<mtd> 0 </mtd>
</mtr>

<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
<mtd> 0 </mtd>
</mtr>

<mtr>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 0 </mtd>
<mtd> 1 </mtd>
</mtr>
</mtable>

</mrow>
</math>
