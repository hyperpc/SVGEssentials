<math>
<mrow>
<mo>5</mo>

<mo>&#8226;</mo>

<mtable>
<mtr>
<mtd> 3 </mtd>
<mtd> 2 </mtd>
</mtr>
<mtr>
<mtd> 5 </mtd>
<mtd> 6 </mtd>
</mtr>
</mtable>

<mo>=</mo>

<mtable>
<mtr>
<mtd> 15 </mtd>
<mtd> 10 </mtd>
</mtr>
<mtr>
<mtd> 25 </mtd>
<mtd> 30 </mtd>
</mtr>
</mtable>

</mrow>
</math>
