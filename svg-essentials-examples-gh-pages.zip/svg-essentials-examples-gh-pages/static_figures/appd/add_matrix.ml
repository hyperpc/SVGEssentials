<math>
<mrow>
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> 2 </mtd>
</mtr>
<mtr>
<mtd> 3 </mtd>
<mtd> 4 </mtd>
</mtr>
<mtr>
<mtd> 5 </mtd>
<mtd> 6 </mtd>
</mtr>
</mtable>
<mo>+</mo>
<mtable>
<mtr>
<mtd> 7 </mtd>
<mtd> 8 </mtd>
</mtr>
<mtr>
<mtd> 9 </mtd>
<mtd> 10 </mtd>
</mtr>
<mtr>
<mtd> 11 </mtd>
<mtd> 12 </mtd>
</mtr>
</mtable>
<mo>=</mo>
<mtable>
<mtr>
<mtd> 1+7 </mtd>
<mtd> 2+8  </mtd>
</mtr>
<mtr>
<mtd> 3+9 </mtd>
<mtd> 4+10 </mtd>
</mtr>
<mtr>
<mtd> 5+11 </mtd>
<mtd> 6+12 </mtd>
</mtr>
</mtable>
<mo>=</mo>
<mtable>
<mtr>
<mtd> 8 </mtd>
<mtd> 10 </mtd>
</mtr>
<mtr>
<mtd> 12 </mtd>
<mtd> 14 </mtd>
</mtr>
<mtr>
<mtd> 16 </mtd>
<mtd> 18 </mtd>
</mtr>
</mtable>
</mrow>
</math>
