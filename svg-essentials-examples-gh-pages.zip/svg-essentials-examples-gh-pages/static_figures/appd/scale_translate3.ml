<math>
<mrow>
<mtable>
<mtr>
<mtd>sx</mtd>
<mtd>0</mtd>
<mtd>tx</mtd>
</mtr>
<mtr>
<mtd>0</mtd>
<mtd>sy</mtd>
<mtd>ty</mtd>
</mtr>
<mtr>
<mtd>0</mtd>
<mtd>0</mtd>
<mtd>1</mtd>
</mtr>
</mtable>
<mo>&#8226;</mo>
<mtable>
<mtr>
<mtd> 3 </mtd>
</mtr>
<mtr>
<mtd> 5 </mtd>
</mtr>
<mtr>
<mtd> 1 </mtd>
</mtr>
</mtable>

<mo>=</mo>

<mtable>
<mtr>
<mtd> sx&#xb7;3 + 0&#xb7;5 + tx&#xb7;1 </mtd>
</mtr>
<mtr>
<mtd> 0&#xb7;3 + sy&#xb7;5 + ty&#xb7;1 </mtd>
</mtr>
<mtr>
<mtd> 0&#xb7;3 + 0&#xb7;5 + 1&#xb7;1 </mtd>
</mtr>
</mtable>

<mo>=</mo>

<mtable>
<mtr>
<mtd> sx&#xb7;3 + tx </mtd>
</mtr>
<mtr>
<mtd> sy&#xb7;5 + ty </mtd>
</mtr>
<mtr>
<mtd> 1 </mtd>
</mtr>
</mtable>

</mrow>
</math>
