<math xmlns="http://www.w3.org/1998/Math/MathML">
<mrow>
<mtable>
<mtr>
<mtd> 3 </mtd>
</mtr>
<mtr>
<mtd> 5 </mtd>
</mtr>
</mtable>
</mrow>
</math>
