<math>
<mrow>
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> 2 </mtd>
<mtd> 3 </mtd>
</mtr>
<mtr>
<mtd> 4 </mtd>
<mtd> 5 </mtd>
<mtd> 6 </mtd>
</mtr>
</mtable>
<mo>&#8226;</mo>
<mtable>
<mtr>
<mtd> 7 </mtd>
<mtd> 10 </mtd>
</mtr>
<mtr>
<mtd> 8 </mtd>
<mtd> 11 </mtd>
</mtr>
<mtr>
<mtd> 9 </mtd>
<mtd> 12 </mtd>
</mtr>
</mtable>

<mo>=</mo>
<mtable>
<mtr>
<mtd> 1&#xb7;7 + 2&#xb7;8 + 3&#xb7;9 </mtd>
<mtd> 1&#xb7;10 + 2&#xb7;11 + 3&#xb7;12  </mtd>
</mtr>
<mtr>
<mtd>  4&#xb7;7 + 5&#xb7;8 + 6&#xb7;9  </mtd>
<mtd>  4&#xb7;10 + 5&#xb7;11 + 6&#xb7;12  </mtd>
</mtr>
</mtable>
<mo>=</mo>
<mtable>
<mtr>
<mtd> 50 </mtd>
<mtd> 68 </mtd>
</mtr>
<mtr>
<mtd> 122 </mtd>
<mtd> 167 </mtd>
</mtr>

</mtable>

</mrow>
</math>
