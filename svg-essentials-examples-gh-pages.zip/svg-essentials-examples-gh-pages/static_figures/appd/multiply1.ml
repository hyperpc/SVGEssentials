<math>
<mrow>
<mtable>
<mtr>
<mtd> 1 </mtd>
<mtd> 2 </mtd>
<mtd> 3 </mtd>
</mtr>
<mtr>
<mtd color="gray"> 4 </mtd>
<mtd color="gray"> 5 </mtd>
<mtd color="gray"> 6 </mtd>
</mtr>
</mtable>
<mo>&#8226;</mo>
<mtable>
<mtr>
<mtd> 7 </mtd>
<mtd color="gray"> 10 </mtd>
</mtr>
<mtr>
<mtd> 8 </mtd>
<mtd color="gray"> 11 </mtd>
</mtr>
<mtr>
<mtd> 9 </mtd>
<mtd color="gray"> 12 </mtd>
</mtr>
</mtable>

<mo>=</mo>
<mtable>
<mtr>
<mtd> 1&#xb7;7 + 2&#xb7;8 + 3&#xb7;9 </mtd>
<mtd color="gray"> - </mtd>
</mtr>
<mtr>
<mtd color="gray"> - </mtd>
<mtd color="gray"> - </mtd>
</mtr>
</mtable>
<mo>=</mo>
<mtable>
<mtr>
<mtd> 50 </mtd>
<mtd color="gray">  - </mtd>
</mtr>
<mtr>
<mtd color="gray"> - </mtd>
<mtd color="gray"> - </mtd>
</mtr>

</mtable>

</mrow>
</math>
